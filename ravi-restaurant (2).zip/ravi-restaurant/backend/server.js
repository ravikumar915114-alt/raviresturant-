const express = require('express');
const cors = require('cors');
require('./seed'); // ensures DB is seeded on first run

const menuRoutes = require('./routes/menu');
const orderRoutes = require('./routes/orders');
const assistantRoutes = require('./routes/assistant');

const app = express();
app.use(cors());
app.use(express.json());

app.get('/api/health', (req, res) => res.json({ ok: true, restaurant: 'Ravi Restaurant' }));
app.use('/api/menu', menuRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/assistant', assistantRoutes);

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Ravi Restaurant API running on http://localhost:${PORT}`);
});
