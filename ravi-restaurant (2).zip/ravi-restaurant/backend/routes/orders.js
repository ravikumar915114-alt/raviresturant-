const express = require('express');
const db = require('../db');
const router = express.Router();

const GST_RATE = 0.05; // 5%

function nextOrderId() {
  const row = db.prepare(`SELECT id FROM orders ORDER BY rowid DESC LIMIT 1`).get();
  if (!row) return 'ORD-1001';
  const n = parseInt(row.id.split('-')[1], 10) || 1000;
  return `ORD-${n + 1}`;
}

// POST /api/orders  { customer_name, table_number, items: [{food_id, size, quantity}] }
router.post('/', (req, res) => {
  const { customer_name, table_number, items } = req.body;

  if (!customer_name || !table_number || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'customer_name, table_number and at least one item are required' });
  }

  const getFood = db.prepare('SELECT * FROM food_items WHERE id = ?');
  let subtotal = 0;
  const lineItems = [];

  for (const it of items) {
    const food = getFood.get(it.food_id);
    if (!food) return res.status(400).json({ error: `Food item ${it.food_id} not found` });

    const size = it.size === 'half' ? 'half' : (food.price_half ? 'full' : null);
    const unitPrice = size === 'half' ? food.price_half : food.price_full;
    if (unitPrice == null) return res.status(400).json({ error: `Invalid size for ${food.name}` });

    const qty = Math.max(1, parseInt(it.quantity, 10) || 1);
    const lineTotal = unitPrice * qty;
    subtotal += lineTotal;

    lineItems.push({ food_id: food.id, name: food.name, size, unit_price: unitPrice, quantity: qty, line_total: lineTotal });
  }

  const gst = Math.round(subtotal * GST_RATE * 100) / 100;
  const total = Math.round((subtotal + gst) * 100) / 100;
  const id = nextOrderId();
  const now = new Date().toISOString();

  const insertOrder = db.prepare(`
    INSERT INTO orders (id, customer_name, table_number, status, subtotal, gst, total, created_at, updated_at)
    VALUES (?, ?, ?, 'Pending', ?, ?, ?, ?, ?)
  `);
  const insertItem = db.prepare(`
    INSERT INTO order_items (order_id, food_id, name, size, unit_price, quantity, line_total)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);

  const tx = db.transaction(() => {
    insertOrder.run(id, customer_name, table_number, subtotal, gst, total, now, now);
    for (const li of lineItems) {
      insertItem.run(id, li.food_id, li.name, li.size, li.unit_price, li.quantity, li.line_total);
    }
  });
  tx();

  res.status(201).json({
    order: { id, customer_name, table_number, status: 'Pending', subtotal, gst, total, created_at: now },
    items: lineItems,
  });
});

// GET /api/orders  (kitchen dashboard feed, newest first)
router.get('/', (req, res) => {
  const { status } = req.query;
  let sql = 'SELECT * FROM orders';
  const params = [];
  if (status) { sql += ' WHERE status = ?'; params.push(status); }
  sql += ' ORDER BY created_at DESC';
  const orders = db.prepare(sql).all(...params);

  const getItems = db.prepare('SELECT * FROM order_items WHERE order_id = ?');
  const full = orders.map((o) => ({ ...o, items: getItems.all(o.id) }));
  res.json({ orders: full });
});

// GET /api/orders/:id
router.get('/:id', (req, res) => {
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  const items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(order.id);
  res.json({ order, items });
});

// PATCH /api/orders/:id/status  { status }
const VALID_STATUSES = ['Pending', 'Preparing', 'Ready', 'Served', 'Cancelled'];
router.patch('/:id/status', (req, res) => {
  const { status } = req.body;
  if (!VALID_STATUSES.includes(status)) {
    return res.status(400).json({ error: `status must be one of ${VALID_STATUSES.join(', ')}` });
  }
  const order = db.prepare('SELECT * FROM orders WHERE id = ?').get(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });

  if (status === 'Cancelled' && order.status === 'Preparing') {
    return res.status(409).json({ error: 'Order is already being prepared. Cancellation needs staff approval.' });
  }

  db.prepare('UPDATE orders SET status = ?, updated_at = ? WHERE id = ?').run(status, new Date().toISOString(), order.id);
  res.json({ ok: true, id: order.id, status });
});

module.exports = router;
