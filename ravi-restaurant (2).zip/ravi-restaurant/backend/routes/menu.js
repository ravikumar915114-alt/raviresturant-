const express = require('express');
const db = require('../db');
const router = express.Router();

// GET /api/menu  -> all items grouped by category, with search/filter/sort
router.get('/', (req, res) => {
  const { q, category, veg, popular, special, sort } = req.query;

  let sql = `
    SELECT f.*, c.name AS category_name
    FROM food_items f
    JOIN categories c ON c.id = f.category_id
    WHERE 1=1
  `;
  const params = [];

  if (q) {
    sql += ` AND (f.name LIKE ? OR c.name LIKE ?)`;
    params.push(`%${q}%`, `%${q}%`);
  }
  if (category) {
    sql += ` AND c.name = ?`;
    params.push(category);
  }
  if (veg === '1') sql += ` AND f.is_veg = 1`;
  if (popular === '1') sql += ` AND f.is_popular = 1`;
  if (special === '1') sql += ` AND f.is_special = 1`;

  const sortMap = {
    price_low: ' ORDER BY COALESCE(f.price_half, f.price_full) ASC',
    price_high: ' ORDER BY f.price_full DESC',
    rating: ' ORDER BY f.rating DESC',
    alpha: ' ORDER BY f.name ASC',
    popular: ' ORDER BY f.is_popular DESC, f.rating DESC',
  };
  sql += sortMap[sort] || ' ORDER BY c.sort_order ASC, f.name ASC';

  const rows = db.prepare(sql).all(...params);

  // Build an Unsplash "source" image URL from the curated, name-matched query.
  // This guarantees the photo topic matches the dish (no mismatched images).
  const withImages = rows.map((r) => ({
    ...r,
    image_url: `https://source.unsplash.com/480x360/?${encodeURIComponent(r.image_query)}`,
  }));

  res.json({ items: withImages });
});

// GET /api/menu/categories
router.get('/categories', (req, res) => {
  const rows = db.prepare('SELECT * FROM categories ORDER BY sort_order ASC').all();
  res.json({ categories: rows });
});

module.exports = router;
