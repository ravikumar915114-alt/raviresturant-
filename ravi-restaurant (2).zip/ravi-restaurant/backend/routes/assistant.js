const express = require('express');
const db = require('../db');
const router = express.Router();

// Lightweight rule-based assistant: matches food names/keywords in free text,
// answers veg/spicy/budget questions, and returns items it thinks the
// customer wants to add (frontend still asks for confirmation before adding).
// No external LLM API key is required for this to work.

function getAllItems() {
  return db.prepare(`
    SELECT f.*, c.name AS category_name FROM food_items f
    JOIN categories c ON c.id = f.category_id
  `).all();
}

router.post('/ask', (req, res) => {
  const { message } = req.body;
  if (!message || typeof message !== 'string') {
    return res.status(400).json({ error: 'message is required' });
  }
  const text = message.toLowerCase();
  const items = getAllItems();

  // 1. Direct name matches (handles "2 tea and 1 samosa", "veg burger order karo")
  const matched = [];
  for (const item of items) {
    const nameLower = item.name.toLowerCase();
    if (text.includes(nameLower)) {
      const qtyMatch = text.match(new RegExp(`(\\d+)\\s*(?:x|\\*)?\\s*${nameLower}|${nameLower}\\s*(?:x|\\*)?\\s*(\\d+)`));
      const qty = qtyMatch ? parseInt(qtyMatch[1] || qtyMatch[2], 10) : 1;
      matched.push({ food_id: item.id, name: item.name, quantity: qty || 1, price: item.price_full });
    }
  }

  if (matched.length > 0) {
    const list = matched.map((m) => `${m.quantity} x ${m.name}`).join(', ');
    return res.json({
      reply: `Sure! I found: ${list}. Shall I add these to your cart?`,
      suggested_items: matched,
      intent: 'add_to_cart',
    });
  }

  // 2. Budget-based recommendation: "kuch 50 rupye ke andar"
  const budgetMatch = text.match(/(\d{2,4})\s*(?:rs|rupy|rupee|₹|budget|under|ke andar)/);
  if (budgetMatch) {
    const budget = parseInt(budgetMatch[1], 10);
    const within = items
      .filter((i) => (i.price_half ?? i.price_full) <= budget)
      .sort((a, b) => b.rating - a.rating)
      .slice(0, 5);
    return res.json({
      reply: within.length
        ? `Within ₹${budget}, I'd recommend: ${within.map((i) => i.name).join(', ')}.`
        : `I couldn't find anything within ₹${budget}, our cheapest item starts a bit higher.`,
      suggested_items: within.map((i) => ({ food_id: i.id, name: i.name, quantity: 1, price: i.price_full })),
      intent: 'recommend',
    });
  }

  // 3. Spicy preference
  if (text.includes('spicy') || text.includes('tikha') || text.includes('teekha')) {
    const spicy = items.filter((i) => i.spicy_level >= 2).sort((a, b) => b.rating - a.rating).slice(0, 5);
    return res.json({
      reply: `Here are some of our spicier dishes: ${spicy.map((i) => i.name).join(', ')}.`,
      suggested_items: spicy.map((i) => ({ food_id: i.id, name: i.name, quantity: 1, price: i.price_full })),
      intent: 'recommend',
    });
  }

  // 4. Today's special / popular
  if (text.includes('special') || text.includes('aaj ka special')) {
    const special = items.filter((i) => i.is_special);
    return res.json({
      reply: special.length ? `Today's special: ${special.map((i) => i.name).join(', ')}.` : `No special is set today, but our popular dishes are great too!`,
      suggested_items: special.map((i) => ({ food_id: i.id, name: i.name, quantity: 1, price: i.price_full })),
      intent: 'recommend',
    });
  }
  if (text.includes('popular') || text.includes('best') || text.includes('recommend') || text.includes('suggest')) {
    const popular = items.filter((i) => i.is_popular).sort((a, b) => b.rating - a.rating).slice(0, 5);
    return res.json({
      reply: `Our most popular dishes: ${popular.map((i) => i.name).join(', ')}.`,
      suggested_items: popular.map((i) => ({ food_id: i.id, name: i.name, quantity: 1, price: i.price_full })),
      intent: 'recommend',
    });
  }

  // 5. Fallback
  return res.json({
    reply: `I can help you order! Try saying something like "2 tea and 1 samosa" or "recommend something spicy under ₹80".`,
    suggested_items: [],
    intent: 'none',
  });
});

module.exports = router;
