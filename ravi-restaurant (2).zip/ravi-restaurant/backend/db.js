const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'ravi.db'));
db.pragma('journal_mode = WAL');

db.exec(`
CREATE TABLE IF NOT EXISTS categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  sort_order INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS food_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  image_query TEXT NOT NULL,      -- used to fetch a correctly-matched photo
  is_veg INTEGER DEFAULT 1,
  is_popular INTEGER DEFAULT 0,
  is_special INTEGER DEFAULT 0,
  spicy_level INTEGER DEFAULT 1,  -- 1-3
  prep_minutes INTEGER DEFAULT 10,
  price_half REAL,                -- nullable if item has only single price
  price_full REAL NOT NULL,
  rating REAL DEFAULT 4.5,
  FOREIGN KEY (category_id) REFERENCES categories(id)
);

CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY,            -- e.g. ORD-1001
  customer_name TEXT NOT NULL,
  table_number TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Pending', -- Pending, Preparing, Ready, Served, Cancelled
  subtotal REAL NOT NULL,
  gst REAL NOT NULL,
  total REAL NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS order_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id TEXT NOT NULL,
  food_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  size TEXT,                      -- 'half' | 'full' | null
  unit_price REAL NOT NULL,
  quantity INTEGER NOT NULL,
  line_total REAL NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id),
  FOREIGN KEY (food_id) REFERENCES food_items(id)
);
`);

module.exports = db;
