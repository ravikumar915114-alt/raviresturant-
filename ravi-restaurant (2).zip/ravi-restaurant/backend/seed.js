const db = require('./db');

const categories = [
  'Fast Food',
  'Rice',
  'Chowmein',
  'Gravy',
  'Dosa',
  'Sweets & Drinks',
];

const insertCategory = db.prepare('INSERT OR IGNORE INTO categories (name, sort_order) VALUES (?, ?)');
categories.forEach((c, i) => insertCategory.run(c, i));

const getCatId = (name) => db.prepare('SELECT id FROM categories WHERE name = ?').get(name).id;

// image_query is a precise search phrase used to fetch a photo that actually
// matches the dish name (no mismatched images).
const items = [
  // FAST FOOD
  { cat: 'Fast Food', name: 'Samosa', desc: 'Crispy fried pastry stuffed with spiced potato filling', img: 'indian samosa snack', veg: 1, popular: 1, special: 0, spicy: 2, prep: 8, half: null, full: 10 },
  { cat: 'Fast Food', name: 'Matar Samosa', desc: 'Samosa stuffed with spiced green peas', img: 'matar samosa indian snack', veg: 1, popular: 0, special: 0, spicy: 2, prep: 8, half: null, full: 25 },
  { cat: 'Fast Food', name: 'Bread Pakoda', desc: 'Bread slices stuffed and deep fried in gram flour batter', img: 'bread pakora indian snack', veg: 1, popular: 0, special: 0, spicy: 1, prep: 8, half: null, full: 10 },
  { cat: 'Fast Food', name: 'Paneer Pakoda', desc: 'Cottage cheese fritters fried in spiced gram flour batter', img: 'paneer pakora fritters', veg: 1, popular: 1, special: 0, spicy: 2, prep: 10, half: null, full: 80 },
  { cat: 'Fast Food', name: 'Chole Bhature', desc: 'Spicy chickpea curry served with fluffy fried bread', img: 'chole bhature indian dish', veg: 1, popular: 1, special: 1, spicy: 2, prep: 15, half: null, full: 60 },
  { cat: 'Fast Food', name: 'Pav Bhaji', desc: 'Mashed vegetable curry served with buttered pav bread', img: 'pav bhaji indian street food', veg: 1, popular: 1, special: 0, spicy: 2, prep: 15, half: null, full: 70 },
  { cat: 'Fast Food', name: 'Veg Burger', desc: 'Crispy vegetable patty burger with fresh veggies', img: 'veg burger', veg: 1, popular: 1, special: 0, spicy: 1, prep: 10, half: null, full: 40 },
  { cat: 'Fast Food', name: 'Paneer Burger', desc: 'Grilled paneer patty burger with fresh veggies', img: 'paneer burger', veg: 1, popular: 0, special: 0, spicy: 1, prep: 10, half: null, full: 50 },
  { cat: 'Fast Food', name: 'Pav Butter', desc: 'Soft pav bread toasted with butter', img: 'butter pav bread', veg: 1, popular: 0, special: 0, spicy: 0, prep: 5, half: null, full: 20 },

  // RICE
  { cat: 'Rice', name: 'Veg Rice', desc: 'Steamed rice tossed with mixed vegetables', img: 'vegetable fried rice', veg: 1, popular: 0, special: 0, spicy: 1, prep: 12, half: 40, full: 80 },
  { cat: 'Rice', name: 'Paneer Rice', desc: 'Steamed rice tossed with paneer cubes and spices', img: 'paneer fried rice', veg: 1, popular: 0, special: 0, spicy: 1, prep: 12, half: 60, full: 120 },
  { cat: 'Rice', name: 'Chole Rice', desc: 'Steamed rice served with spicy chickpea curry', img: 'chole rice indian', veg: 1, popular: 0, special: 0, spicy: 2, prep: 12, half: null, full: 60 },
  { cat: 'Rice', name: 'Veg Biryani', desc: 'Fragrant basmati rice layered with mixed vegetables and spices', img: 'vegetable biryani', veg: 1, popular: 1, special: 1, spicy: 2, prep: 18, half: 70, full: 140 },

  // CHOWMEIN
  { cat: 'Chowmein', name: 'Veg Chowmein', desc: 'Stir-fried noodles tossed with fresh vegetables', img: 'vegetable chowmein noodles', veg: 1, popular: 1, special: 0, spicy: 2, prep: 12, half: 40, full: 80 },
  { cat: 'Chowmein', name: 'Paneer Chowmein', desc: 'Stir-fried noodles tossed with paneer and vegetables', img: 'paneer chowmein noodles', veg: 1, popular: 0, special: 0, spicy: 2, prep: 12, half: 60, full: 120 },

  // GRAVY
  { cat: 'Gravy', name: 'Chilli Paneer Gravy', desc: 'Paneer cubes tossed in spicy chilli gravy sauce', img: 'chilli paneer gravy', veg: 1, popular: 1, special: 0, spicy: 3, prep: 15, half: 90, full: 170 },
  { cat: 'Gravy', name: 'Chilli Paneer Dry', desc: 'Paneer cubes tossed in spicy dry chilli masala', img: 'chilli paneer dry', veg: 1, popular: 0, special: 0, spicy: 3, prep: 15, half: 80, full: 150 },
  { cat: 'Gravy', name: 'Manchurian Gravy', desc: 'Vegetable balls in a tangy Indo-Chinese gravy', img: 'veg manchurian gravy', veg: 1, popular: 1, special: 0, spicy: 2, prep: 15, half: 80, full: 150 },
  { cat: 'Gravy', name: 'Manchurian Dry', desc: 'Vegetable balls tossed in a tangy dry Manchurian sauce', img: 'veg manchurian dry', veg: 1, popular: 0, special: 0, spicy: 2, prep: 15, half: 70, full: 130 },

  // DOSA
  { cat: 'Dosa', name: 'Paper Dosa', desc: 'Thin and crispy fermented rice and lentil crepe', img: 'paper dosa south indian', veg: 1, popular: 0, special: 0, spicy: 1, prep: 12, half: null, full: 50 },
  { cat: 'Dosa', name: 'Masala Dosa', desc: 'Crispy dosa filled with spiced potato masala', img: 'masala dosa south indian', veg: 1, popular: 1, special: 1, spicy: 1, prep: 14, half: null, full: 80 },
  { cat: 'Dosa', name: 'Paneer Dosa', desc: 'Crispy dosa filled with spiced paneer masala', img: 'paneer dosa', veg: 1, popular: 0, special: 0, spicy: 1, prep: 14, half: null, full: 100 },

  // SWEETS & DRINKS
  { cat: 'Sweets & Drinks', name: 'Rasmalai', desc: 'Soft cottage cheese dumplings in sweet saffron milk', img: 'rasmalai indian sweet', veg: 1, popular: 0, special: 0, spicy: 0, prep: 5, half: null, full: 35 },
  { cat: 'Sweets & Drinks', name: 'Ras Madhuri', desc: 'Rich milk-based Indian sweet delicacy', img: 'indian milk sweet ras madhuri', veg: 1, popular: 0, special: 0, spicy: 0, prep: 5, half: null, full: 50 },
  { cat: 'Sweets & Drinks', name: 'Peda', desc: 'Traditional Indian milk-based sweet', img: 'peda indian sweet', veg: 1, popular: 0, special: 0, spicy: 0, prep: 3, half: null, full: 10 },
  { cat: 'Sweets & Drinks', name: 'Lassi', desc: 'Chilled sweet yogurt-based drink', img: 'sweet lassi glass', veg: 1, popular: 1, special: 0, spicy: 0, prep: 5, half: null, full: 40 },
  { cat: 'Sweets & Drinks', name: 'Tea', desc: 'Hot Indian masala chai', img: 'indian masala chai tea cup', veg: 1, popular: 1, special: 0, spicy: 0, prep: 5, half: null, full: 10 },
];

const insertItem = db.prepare(`
  INSERT INTO food_items
  (category_id, name, description, image_query, is_veg, is_popular, is_special, spicy_level, prep_minutes, price_half, price_full, rating)
  VALUES (@category_id, @name, @description, @image_query, @is_veg, @is_popular, @is_special, @spicy_level, @prep_minutes, @price_half, @price_full, @rating)
`);

const existingCount = db.prepare('SELECT COUNT(*) AS c FROM food_items').get().c;
if (existingCount === 0) {
  const insertMany = db.transaction((rows) => {
    for (const r of rows) {
      insertItem.run({
        category_id: getCatId(r.cat),
        name: r.name,
        description: r.desc,
        image_query: r.img,
        is_veg: r.veg,
        is_popular: r.popular,
        is_special: r.special,
        spicy_level: r.spicy,
        prep_minutes: r.prep,
        price_half: r.half,
        price_full: r.full,
        rating: 4.3 + Math.random() * 0.6,
      });
    }
  });
  insertMany(items);
  console.log(`Seeded ${items.length} food items across ${categories.length} categories.`);
} else {
  console.log('Food items already seeded, skipping.');
}
